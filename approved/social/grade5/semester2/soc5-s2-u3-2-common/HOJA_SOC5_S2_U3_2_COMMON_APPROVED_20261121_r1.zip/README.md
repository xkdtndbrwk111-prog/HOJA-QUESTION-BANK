# HOJA 사회 5학년 2학기 8·15 광복과 6·25 전쟁 — 교사 승인 정본 r1

- 승인: 2026-11-21
- 카트리지: `soc5-s2-u3-2-common` · revision 5
- 문항: 32(MCQ 22, OX 6, SHORT 4)
- 최종 렌더 화면: `presentation/HOJA_SOC5_U3_1_U3_2_APPROVED_64Q_20261121.html` (오프라인 단일 HTML, 두 단원 64문항)
- **반드시 `effective/cartridge.json`와 `effective/assets/`를 한 세트로 사용한다.** 원본 후보의 4개 도표 대신, 검토 HTML에 실제 사용된 글씨 큰 1600×900 도표 2개를 이 단원에 반영했다.
- `source-candidate/`: 제출 당시 ZIP 원본을 증빙용으로 보존. 이 안의 그림을 최종 승인 그림으로 간주하지 않는다.
- `release/approval.json`, `release/file-manifest.json`: 교사 승인 상태, 배포 보류, 파일별 SHA256, 검사 경계.
- 3-2 q13: 선택지의 날짜(8·15, 5·10)를 제거하고 사건 이름으로만 제시. 정답 c2 그대로.
- **운영 게임 미배포**. 실제 전자칠판 실기기·게임 점수 연동·공개 미디어 권리는 별도 시험/확인 필요.

이 패키지의 정본 r1과 원본 카트리지 revision 5은 서로 다른 버전 축이다.
