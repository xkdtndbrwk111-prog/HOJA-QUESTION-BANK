# HOJA 과학 5학년 2학기 4단원 「자원과 에너지」 — 교사 승인 정본 r1

- 승인: 2026-11-21
- 카트리지: `sci5-s2-u4-common` · revision 3
- 문항: 32 (MCQ 22, OX 6, SHORT 4)
- 최종 승인 화면: `presentation/HOJA_SCI5_S2_HEAT_U4_APPROVED_64Q_20261121.html`
- **반드시 `effective/cartridge.json`와 `effective/assets/`를 함께 사용한다.**
- `source-candidate/`에는 제출 당시 ZIP 원본을 증빙용으로 보존했다.
- 4단원은 rev3 과학 표현 수정본을 그대로 승인했다.
- 운영 게임 미배포. 실제 전자칠판 실기기·점수 연동은 별도 확인 필요.

이 패키지의 정본 r1과 원본 카트리지 revision 3은 서로 다른 버전 축이다.
