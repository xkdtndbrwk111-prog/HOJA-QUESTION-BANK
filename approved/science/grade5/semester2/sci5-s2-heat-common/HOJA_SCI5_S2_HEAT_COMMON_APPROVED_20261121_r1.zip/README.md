# HOJA 과학 5학년 2학기 3단원 「열과 우리 생활」 — 교사 승인 정본 r1

- 승인: 2026-11-21
- 카트리지: `sci5-s2-heat-common` · revision 3
- 문항: 32 (MCQ 22, OX 6, SHORT 4)
- 최종 승인 화면: `presentation/HOJA_SCI5_S2_HEAT_U4_APPROVED_64Q_20261121.html`
- **반드시 `effective/cartridge.json`와 `effective/assets/`를 함께 사용한다.**
- `source-candidate/`에는 제출 당시 ZIP 원본을 증빙용으로 보존했다.
- 3단원 Q04는 승인 화면에서 **그림 왼쪽 · 보기 오른쪽(좌우배치)**로 고정했다.
- 운영 게임 미배포. 실제 전자칠판 실기기·점수 연동은 별도 확인 필요.

이 패키지의 정본 r1과 원본 카트리지 revision 3은 서로 다른 버전 축이다.
