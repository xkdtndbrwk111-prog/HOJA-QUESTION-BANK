# HOJA 수학 6-2-5 원의 둘레와 넓이 — 교사 승인 r1

2026-11-22 교사 승인. 31문항, 7개 WebP. source-candidate 는 이전 검토 후보 상태 그대로 보존했음. 최종 콘텐츠는 effective/cartridge.json 및 effective/assets/ 참조. 19개 C형 선호 및 4개 줄바꿈은 presentation/layout-preferences.json과 통합 검토 HTML에 고정. 게임 배포는 별도.
